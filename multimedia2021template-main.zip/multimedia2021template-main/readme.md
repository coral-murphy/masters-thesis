Multimedia 2021 Web Template
============

This is a simple web starter project that includes Bootstrap, jQuery, and [jQuery Scroll Swap](https://github.com/jrue/jquery-scroll-swap). 

The main template is in the `index.html` file. You will need a code editor like [Bracket.io](https://brackets.io/) (recommended) or [Visual Studio Code](https://code.visualstudio.com/) (More difficult to use, but more powerful.)

You can view an example of this template here:

[https://ucbsoj.github.io/multimedia2021template/](https://ucbsoj.github.io/multimedia2021template/)




